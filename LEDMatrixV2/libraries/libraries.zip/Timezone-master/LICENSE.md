#Arduino Timezone Library 1.1.0
https://github.com/JChristensen/Timezone  
LICENSE file  
Jack Christensen Mar 2012  

![CC BY-SA](http://mirrors.creativecommons.org/presskit/buttons/88x31/png/by-sa.png)
##CC BY-SA
Arduino Timezone Library by Jack Christensen is licensed under [CC BY-SA 4.0](http://creativecommons.org/licenses/by-sa/4.0/).

